---
title: Urdu Audio & Video Speech Analyzer
emoji: 🎙️
colorFrom: indigo
colorTo: blue
sdk: streamlit
app_file: app.py
pinned: false
---

Record or upload Urdu speech for transcription + diarization + analysis.
